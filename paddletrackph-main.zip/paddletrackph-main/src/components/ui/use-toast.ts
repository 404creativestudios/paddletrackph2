import { useToast, toast } from "@/hooks/use-toast";

export { useToast, toast };
